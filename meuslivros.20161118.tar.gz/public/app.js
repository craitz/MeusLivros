(function() {

  // Initialize Firebase
  var config = {
    apiKey: "AIzaSyBSYd7ZVSbJu4UjxKgO8iWvvgDgIv68YdU",
    authDomain: "meus-livros-9fa07.firebaseapp.com",
    databaseURL: "https://meus-livros-9fa07.firebaseio.com",
    storageBucket: "meus-livros-9fa07.appspot.com",
    messagingSenderId: "909272950135"
  };

  firebase.initializeApp(config);

  angular.module('app', ['firebase', 'ui.bootstrap', 'ngRoute', 'ngMessages', 'chart.js']);

})();
