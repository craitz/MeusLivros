$('.btn-toggle').click(function() {
    toggleNav();
});
