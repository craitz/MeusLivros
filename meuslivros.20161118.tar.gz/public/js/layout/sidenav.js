function toggleNav() {
    if ($('.sidenav').hasClass('active')) {
      closeNav();
    } else {
      openNav();
    }
}

/* Set the width of the side navigation to 250px */
function openNav() {
    document.getElementById("mySidenav").style.width = "200px";
    $('.sidenav-container').show();
    $('.sidenav').addClass('active');
}

/* Set the width of the side navigation to 0 */
function closeNav() {
  $('.sidenav-container').hide();
  document.getElementById("mySidenav").style.width = "0";
  $('.sidenav').removeClass('active');
}

$('.sidenav a').click(function() {
  closeNav();
});
