angular.module('app').value('config', {
  firebaseUrl: 'https://meus-livros-9fa07.firebaseio.com/',
  timeoutAfterRenderSelect: 10 //ms
});
