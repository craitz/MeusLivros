angular.module("app").factory("ModalCategoriaFactory", function($uibModal) {
  var modalInstance = {};

  var _open = function(categoria, scope) {
    modalInstance = $uibModal.open({
      templateUrl: 'views/categorias/modal-categoria.html',
      controller: 'CadastroCategoriasController',
      size: 'sm',
      resolve: {
        novoCategoria: function () {
          return categoria;
        },
        caller: function () {
          return scope;
        }
      }
    });
  };

  var _close = function() {
    modalInstance.close();
  };

  return {
    open: _open,
    close: _close
  };
});
