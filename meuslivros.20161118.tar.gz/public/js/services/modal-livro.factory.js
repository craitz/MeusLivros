angular.module("app").factory("ModalLivroFactory", function($uibModal) {
  var modalInstance = {};

  var _open = function(livro, scope) {
    modalInstance = $uibModal.open({
      templateUrl: 'views/livros/modal-livro.html',
      controller: 'CadastroLivroController',
      size: 'lg',
      resolve: {
        livroData: function () {
          return livro;
        },
        caller: function () {
          return scope;
        }
      }
    });
  };

  var _close = function() {
    modalInstance.close();
  };

  return {
    open: _open,
    close: _close
  };
});
