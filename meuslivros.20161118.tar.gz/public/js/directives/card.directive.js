angular.module('app').directive('crCard', function() {
  return {
    templateUrl: 'views/ui/ui-card.html',
    scope: {
      valor: '=',
      modelo: '@',
      icone: '@',
      color: '@'
    }
  };
});
