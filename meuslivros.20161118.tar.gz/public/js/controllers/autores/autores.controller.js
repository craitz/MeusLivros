angular.module('app').controller('AutoresController',
function($scope, $firebaseObject, ModelFactory, ModalAutorFactory, UsersFactory) {

  UsersFactory.getBaseRef().then(function(ref) {

    //monitora mudanças no BD
    ref.child('autores').on('value', function(listData) {
      $scope.$evalAsync(function() {
        $scope.autores = ModelFactory.buildModelList(listData);
      });
    });

    $scope.ordenarPor = function(campo) {
      $scope.ordenacao = campo;
      $scope.direcao = ($scope.direcao === undefined) ? false : !$scope.direcao;
    };

    $scope.abrirModal = function(autor) {
      ModalAutorFactory.open(angular.copy(autor), $scope);
    };

    $scope.excluirAutor = function(autor) {
      $scope.$evalAsync(
        function() {
          //messagebox de exclusão
          swal(
            {
              title: 'Tem certeza?',
              text: 'Deseja excluir o autor "' + autor.nome + '"?',
              showCancelButton: true,
              confirmButtonColor: '#DD6B55',
              confirmButtonText: 'Sim, exclua agora!',
              closeOnConfirm: false
            },
            function(isConfirm) {
              //se confirmou a exclusão
              if (isConfirm) {

                //remove do BD
                ModelFactory.remover('autores', autor.id).then(function() {
                  //messagebox confirmando a exclusão
                  swal('Pronto!', 'Autor "' + autor.nome + '" excluído com sucesso!', 'success');
                });
              }
            }
          );
        }
      );
    };
  });

});
