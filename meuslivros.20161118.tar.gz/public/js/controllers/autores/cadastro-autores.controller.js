angular.module('app').controller('CadastroAutoresController',
function($scope, $rootScope, ModelFactory, ModalAutorFactory, novoAutor, caller) {

  $scope.novoAutor = novoAutor;
  $scope.nomes = angular.copy(caller.autores);
  $scope.title = (novoAutor === undefined) ? 'Adicionar autor' : 'Editar autor';

  $scope.salvarAutor = function(autor) {
    //monta o objeto
    var novo = {
      id: (autor.id === undefined) ? (Date.now() + "") : autor.id,
      nome: $scope.novoAutor.nome
    };

    ModelFactory.salvar('autores', novo).then(function(idNovo) {
        // quando o modal é chamado do cadastro de livros,
        // a combo de autores precisa ser atualizada com o
        // nome do novo autor
        $rootScope.$broadcast('updateCombo', {model: 'autor', id: idNovo});

        // fecha o modal
        ModalAutorFactory.close();
    });
  };

  $scope.fecharModal = function() {
    ModalAutorFactory.close();
  };
});
