angular.module('app').controller('LivrosController',
function($scope, $sce, ModelFactory, UsersFactory, ModalLivroFactory, $location) {

  // todas as funções da aplicação dependem do usuário logado
  // e, em consequencia, do baseRef do firebase. Então todas as
  // páginas só carregam depois de ter o usuário logado e carregado
  UsersFactory.getBaseRef().then(function(ref) {

    ref.child('livros').on('value', function(listData) {
      $scope.livros = [];
      listData.forEach(function(livroSnap) {
        var livro = ModelFactory.snapshotToObject(livroSnap);
        livro.htmlPopover = $sce.trustAsHtml(
          '<img src="' + livro.capa.downloadUrl + '" style="width: 200px; height: 330px"></img>'
        );

        ref.child('autores').child(livroSnap.val().autor)
          .once('value', function(autorSnap) {
            livro.autor = ModelFactory.snapshotToObject(autorSnap);

            ref.child('categorias').child(livroSnap.val().categoria)
              .once('value', function(categoriasSnap) {
                livro.categoria = ModelFactory.snapshotToObject(categoriasSnap);

                ref.child('idiomas').child(livroSnap.val().idioma)
                  .once('value', function(idiomasSnap) {
                    livro.idioma = ModelFactory.snapshotToObject(idiomasSnap);

                    $scope.$evalAsync(function() {
                      $scope.livros.push(livro);
                    });
                  });
              });
          });
        });
    });

    $scope.abrirModal = function(livro) {
      ModalLivroFactory.open(angular.copy(livro), $scope);
    };

    $scope.ordenarPor = function(campo) {
      $scope.ordenacao = campo;

      switch ($scope.ordenacao) {
        case 'titulo':
        $scope.direcaoTitulo = ($scope.direcaoTitulo === undefined) ? false : !$scope.direcaoTitulo;
        $scope.direcao = $scope.direcaoTitulo;
        $scope.direcaoAno = undefined;
        $scope.direcaoEdicao = undefined;
        $scope.direcaoPaginas = undefined;
        $scope.direcaoAutor = undefined;
        $scope.direcaoCategoria = undefined;
        $scope.direcaoIdioma = undefined;
        break;
        case 'ano':
        $scope.direcaoAno = ($scope.direcaoAno === undefined) ? false : !$scope.direcaoAno;
        $scope.direcao = $scope.direcaoAno;
        $scope.direcaoTitulo = undefined;
        $scope.direcaoEdicao = undefined;
        $scope.direcaoPaginas = undefined;
        $scope.direcaoAutor = undefined;
        $scope.direcaoCategoria = undefined;
        $scope.direcaoIdioma = undefined;
        break;
        case 'edicao':
        $scope.direcaoEdicao = ($scope.direcaoEdicao === undefined) ? false : !$scope.direcaoEdicao;
        $scope.direcao = $scope.direcaoEdicao;
        $scope.direcaoTitulo = undefined;
        $scope.direcaoAno = undefined;
        $scope.direcaoPaginas = undefined;
        $scope.direcaoAutor = undefined;
        $scope.direcaoCategoria = undefined;
        $scope.direcaoIdioma = undefined;
        break;
        case 'paginas':
        $scope.direcaoPaginas = ($scope.direcaoPaginas === undefined) ? false : !$scope.direcaoPaginas;
        $scope.direcao = $scope.direcaoPaginas;
        $scope.direcaoTitulo = undefined;
        $scope.direcaoAno = undefined;
        $scope.direcaoEdicao = undefined;
        $scope.direcaoAutor = undefined;
        $scope.direcaoCategoria = undefined;
        $scope.direcaoIdioma = undefined;
        break;
        case 'autor.nome':
        $scope.direcaoAutor = ($scope.direcaoAutor === undefined) ? false : !$scope.direcaoAutor;
        $scope.direcao = $scope.direcaoAutor;
        $scope.direcaoTitulo = undefined;
        $scope.direcaoAno = undefined;
        $scope.direcaoEdicao = undefined;
        $scope.direcaoPaginas = undefined;
        $scope.direcaoCategoria = undefined;
        $scope.direcaoIdioma = undefined;
        break;
        case 'categoria.nome':
        $scope.direcaoCategoria = ($scope.direcaoCategoria === undefined) ? false : !$scope.direcaoCategoria;
        $scope.direcao = $scope.direcaoCategoria;
        $scope.direcaoTitulo = undefined;
        $scope.direcaoAno = undefined;
        $scope.direcaoEdicao = undefined;
        $scope.direcaoPaginas = undefined;
        $scope.direcaoAutor = undefined;
        $scope.direcaoIdioma = undefined;
        break;
        case 'idioma.nome':
        $scope.direcaoIdioma = ($scope.direcaoIdioma === undefined) ? false : !$scope.direcaoIdioma;
        $scope.direcao = $scope.direcaoIdioma;
        $scope.direcaoTitulo = undefined;
        $scope.direcaoAno = undefined;
        $scope.direcaoEdicao = undefined;
        $scope.direcaoPaginas = undefined;
        $scope.direcaoAutor = undefined;
        $scope.direcaoCategoria = undefined;
        break;
      }
    };

    $scope.limparPesquisa = function() {
      $scope.filtroTitulo = '';
      $scope.filtroAno = '';
      $scope.filtroPaginas = '';
      $scope.filtroAutor = '';
      $scope.filtroCategoria = '';
      $scope.filtroIdioma = '';
    };

    $scope.excluirLivro = function(livro) {
      $scope.$evalAsync(
        function() {
          //messagebox de exclusão
          swal(
            {
              title: 'Tem certeza?',
              text: 'Deseja excluir o livro "' + livro.titulo + '"?',
              showCancelButton: true,
              confirmButtonColor: '#DD6B55',
              confirmButtonText: 'Sim, exclua agora!',
              closeOnConfirm: true
            },
            function(isConfirm) {
              //se confirmou a exclusão
              if (isConfirm) {

                //remove do BD
                ModelFactory.remover('livros', livro.id).then(function() {
                  //messagebox confirmando a exclusão
                  swal('Pronto!', 'Livro "' + livro.titulo + '" excluído com sucesso!', 'success');
                });
              }
            }
          );
        }
      );
    };

    $scope.isUserLogged = function() {
      return (UsersFactory.getLoggedUser() !== null);
    };
  });

});
