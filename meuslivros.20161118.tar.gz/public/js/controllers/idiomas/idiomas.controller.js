angular.module('app').controller('IdiomasController',
function($scope, $firebaseObject, ModalIdiomaFactory, ModelFactory, UsersFactory) {

  UsersFactory.getBaseRef().then(function(ref) {

    //monitora mudanças no BD
    ref.child('idiomas').on('value', function(listData) {
      $scope.$evalAsync(function() {
        $scope.idiomas = ModelFactory.buildModelList(listData);
      });
    });

    $scope.ordenarPor = function(campo) {
      $scope.ordenacao = campo;
      $scope.direcao = ($scope.direcao === undefined) ? false : !$scope.direcao;
    };

    $scope.abrirModal = function(idioma) {
      ModalIdiomaFactory.open(angular.copy(idioma), $scope);
    };

    $scope.excluirIdioma = function(idioma) {
      $scope.$evalAsync(
        function() {
          //messagebox de exclusão
          swal(
            {
              title: 'Tem certeza?',
              text: 'Deseja excluir o idioma "' + idioma.nome + '"?',
              showCancelButton: true,
              confirmButtonColor: '#DD6B55',
              confirmButtonText: 'Sim, exclua agora!',
              closeOnConfirm: false
            },
            function(isConfirm) {
              //se confirmou a exclusão
              if (isConfirm) {

                //remove do BD
                ModelFactory.remover('idiomas', idioma.id).then(function() {
                  //messagebox confirmando a exclusão
                  swal('Pronto!', 'Idioma "' + idioma.nome + '" excluído com sucesso!', 'success');
                });
              }
            }
          );
        }
      );
    };
  });

});
