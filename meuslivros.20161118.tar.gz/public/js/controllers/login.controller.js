angular.module('app').controller('LoginController', function($scope, UsersFactory, $location) {

  $scope.loginUser = function(loginData) {
    UsersFactory.login(loginData).then(function() {
      $location.path('/livros');
    })
    .catch(function(err) {
      $scope.erroLogin = true;

      switch (err.code) {
        case 'auth/wrong-password':
          $scope.mensagemErro = 'Senha inválida!';
          break;
        case 'auth/invalid-email':
          $scope.mensagemErro = 'E-mail inválido!';
          break;
        case 'auth/user-not-found':
          $scope.mensagemErro = 'E-mail não cadastrado!';
          break;
        default:
          console.log(err.code);
      }
    });
  };

  $scope.createUser = function(loginData) {
    UsersFactory.create(loginData).then(function() {
      $location.path('/livros');
    })
    .catch(function(err) {
      $scope.erroLogin = true;

      switch (err.code) {
        case 'auth/invalid-email':
          $scope.mensagemErro = 'E-mail inválido!';
          break;
        case 'auth/email-already-in-use':
          $scope.mensagemErro = 'E-mail já existente!';
          break;
        default:
          console.log(err.code);
      }
    });
  };

  // quando digitar qualquer coisa no form,
  // apaga a mensagem de erro
  $('#formLogin').keyup(function() {
    $scope.$evalAsync(function() {
      $scope.erroLogin = false;
    });
  });

  // quando mudar qualquer coisa no form,
  // apaga a mensagem de erro
  $('#formLogin').change(function() {
    $scope.$evalAsync(function() {
      $scope.erroLogin = false;
    });
  });

});
