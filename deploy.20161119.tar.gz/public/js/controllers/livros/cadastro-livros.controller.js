angular.module('app').controller('CadastroLivroController',
function($scope, $timeout, ModelFactory, $location, UsersFactory,
  ModalCategoriaFactory, ModalAutorFactory, ModalIdiomaFactory, ModalLivroFactory,
  livroData, caller) {

  UsersFactory.getBaseRef().then(function(ref) {

    $scope.title = 'Adicionar livro';
    $scope.statusUpload = 0;
    $scope.isNovo = true;
    $scope.categorias = [];
    $scope.idiomas = [];
    $scope.autores = [];
    $scope.nomes = [];

    // monitora mudanças na lista de autores
    ref.child('autores').on('value', function(listData) {
      $scope.$evalAsync(function() {
        $scope.autores = ModelFactory.buildModelList(listData);
      });
    });

    // monitora mudanças na lista de categorias
    ref.child('categorias').on('value', function(listData) {
      $scope.$evalAsync(function() {
        $scope.categorias = ModelFactory.buildModelList(listData);
      });
    });

    // monitora mudanças na lista de idiomas
    ref.child('idiomas').on('value', function(listData) {
      $scope.$evalAsync(function() {
        $scope.idiomas = ModelFactory.buildModelList(listData);
      });
    });

    var initModel = function() {
      $timeout(function() {
        $scope.$evalAsync(function() {

          // init values
          $scope.title = 'Editar livro';
          $scope.isNovo = false;
          $scope.livro = livroData;

          // update combos
          $scope.formLivro.autor.$setViewValue($scope.livro.autor.id);
          $scope.formLivro.autor.$render();
          $scope.formLivro.categoria.$setViewValue($scope.livro.categoria.id);
          $scope.formLivro.categoria.$render();
          $scope.formLivro.idioma.$setViewValue($scope.livro.idioma.id);
          $scope.formLivro.idioma.$render();

          // build ref path
          if ($scope.livro.capa.storageUrl.toString().length > 0) {
            var storageRef = firebase.storage().ref($scope.livro.capa.storageUrl);
            $scope.imgsrc = $scope.livro.capa.downloadUrl;
          } else {
            $scope.$evalAsync(function() {
              $scope.imgsrc = 'img/mock.jpg';
            });
          }
        });
      }, 500);
    };

    $scope.fecharModal = function() {
      ModalLivroFactory.close();
    };

    // edição
    if (livroData !== undefined) {
      initModel();
    } else {
      $scope.$evalAsync(function() {
        $scope.imgsrc = 'img/mock.jpg';
        $scope.livro = {
            paginas: 0,
            ano: 0,
        };
      });
    }

    $scope.abrirModal = function(model) {
      switch(model) {
      case 'autor':
      ModalAutorFactory.open(undefined, $scope);
      break;
      case 'categoria':
      ModalCategoriaFactory.open(undefined, $scope);
      break;
      case 'idioma':
      ModalIdiomaFactory.open(undefined, $scope);
      break;
      }
    };

    $scope.salvarLivro = function() {
      $scope.livro.id = $scope.isNovo ? (Date.now() + ""): $scope.livro.id;

      // remove o que não precisa ir para o BD
      delete $scope.livro.htmlPopover;

      ModelFactory.salvarLivro($scope.livro).then(function(livroSalvo) {
        $scope.fecharModal();
      });
    };

    var carregarLivros = function() {
      ModelFactory.listarTitulosLivro().then(function(lista) {
        $scope.nomes = lista;
      });
    };

    $('#imagem').change(function(e) {

      // zera variáveis
      $scope.$evalAsync(function() {

        $('#uploader').show();
        $scope.uploadingImage = true;
        $scope.statusUpload = 0;
      });

      // get the file
      var file = e.target.files[0];

      // se selecionou algum arquivo
      if (file) {
        // build ref path
        var filePath = 'users/' + UsersFactory.getLoggedUserId() + '/' + file.name;

        // create storage ref
        var storageRef = firebase.storage().ref(filePath);

        // upload file
        var task = storageRef.put(file);

        // check status transfer
        task.on('state_changed',

          function progress(snapshot) {

            // atualiza status progress bar
            $scope.$evalAsync(function() {
              $scope.statusUpload = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
            });
          },

          function error(err) {

            // zera variaveis
            $scope.$evalAsync(function() {

              $scope.livro.capa = '';
              $scope.uploadingImage = false;
              $('.uploader').hide();
            });
          },
          function complete() {

            // mostra thumnail
            storageRef.getDownloadURL().then(function(url) {
              $scope.$evalAsync(function() {

                $scope.livro.capa = {
                  storageUrl: filePath,
                  downloadUrl: url
                };

                $scope.uploadingImage = false;
                $scope.imgsrc = url;
              });
            });
          }
        );
      } else {

        // não selecionou nada, então faz nada.
        // só zera o que precisa ser zerado
        $scope.$evalAsync(function() {
          $('.uploader').hide();
          $scope.uploadingImage = false;
        });
      }
    });

    $scope.$on('updateCombo', function(event, data) {
      $timeout(function() {
        $scope.$evalAsync(function() {
          switch(data.model) {
            case 'autor':
            $('select#autor').val(data.id);
            $scope.formLivro.autor.$setValidity('required', true);
            $scope.livro.autor = data.id;
            break;
            case 'categoria':
            $('select#categoria').val(data.id);
            $scope.formLivro.categoria.$setValidity('required', true);
            $scope.livro.categoria = data.id;
            break;
            case 'idioma':
            $('select#idioma').val(data.id);
            $scope.formLivro.idioma.$setValidity('required', true);
            $scope.livro.idioma = data.id;
            break;
          }
        });
      }, 100);
    });

    carregarLivros();
  });

});
