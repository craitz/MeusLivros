angular.module('app').controller('AppController', function($scope, UsersFactory, $location, $rootScope) {

  $rootScope.path = ['home', 'idiomas', 'cadastro'];
  $scope.userLoaded = undefined;

  $scope.isUserLogged = function() {
    return (UsersFactory.getLoggedUser() !== null);
  };

  $scope.getUserName = function() {
    return UsersFactory.getLoggedUserName();
  };

  $scope.getUserId = function() {
    return UsersFactory.getLoggedUserId();
  };

  $scope.logoutUser = function() {
    UsersFactory.logout().then(function() {
      $location.path('/login');
    });
  };

  $rootScope.$on('$routeChangeSuccess', function(event, current, prev) {
    if (!$scope.isUserLogged() && ($scope.userLoaded === true)) {
      $location.path('/login');
    } else if (current.originalPath === '/login') {
        $location.path(prev ? prev.originalPath : '/dashboard');
    }
  });

  firebase.auth().onAuthStateChanged(function(user) {

    // o angular já sabe se o usuário está ou não logado
    $scope.userLoaded = true;

    if (user) {
      //há usuário logado
      $rootScope.baseRef = firebase.database().ref('users/' + UsersFactory.getLoggedUserId());
    } else {
      // ninguém logado
    }
  });
});
