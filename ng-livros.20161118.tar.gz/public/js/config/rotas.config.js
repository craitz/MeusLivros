angular.module('app').config(function($routeProvider) {
  $routeProvider
  .when('/', {
    templateUrl: 'views/dashboard.html',
    controller: 'DashboardController'
  })
  .when('/livros', {
    templateUrl: 'views/livros/livros.html',
    controller: 'LivrosController'
  })
  .when('/livros/:id', {
    templateUrl: 'views/livros/cadastro-livro.html',
    controller: 'CadastroLivroController',
  })
  .when('/autores', {
    templateUrl: 'views/autores/autores.html',
    controller: 'AutoresController'
  })
  .when('/idiomas', {
    templateUrl: 'views/idiomas/idiomas.html',
    controller: 'IdiomasController'
  })
  .when('/categorias', {
    templateUrl: 'views/categorias/categorias.html',
    controller: 'CategoriasController'
  })
  .when('/login', {
    templateUrl: 'views/login.html',
    controller: 'LoginController'
  })
  .otherwise({
    redirectTo: '/'
  });
});
