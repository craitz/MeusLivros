angular.module('app').directive('integerMask', function() {
  return {
    require: 'ngModel',
    link: function(scope, element, attrs, ctrl) {
      var _format = function(val) {

        //restringe a apenas números
        strVal = val.toString().replace(/[^0-9]+/g, '');

        //converte de string pra número, o que vai
        // automaticamente retirar os zeros na frente
        iVal = !isNaN(strVal) ? Number(strVal) : 0;

        //reconverte para string, para poder ser manipulada
        strVal = iVal.toString();

        if (strVal.length >= 4) {
          strVal = strVal.substring(0, 4);
        }

        return strVal;
      };

      element.bind('keyup', function() {
        ctrl.$setViewValue(_format(ctrl.$viewValue));
        ctrl.$render();
      });

      ctrl.$parsers.push(function(val) {
        return val;
      });
    }


  };
});
