// remember, directive name must start with a lower case & use camel case naming convetion
angular.module('app').directive('nomeValidator', function() {
    return {

      // limit usage to argument only
      restrict: 'A',

      // require NgModelController, i.e. require a controller of ngModel directive
      require: 'ngModel',

      // create linking function and pass in our NgModelController as a 4th argument
      link: function(scope, element, attrs, ctrl) {
        function customValidator(ngModelValue) {
          if ( (ngModelValue !== undefined) && (ngModelValue.length > 0) ) {
              ctrl.$setValidity('emptyValidator', true);
          } else {
              ctrl.$setValidity('emptyValidator', false);
          }

          ctrl.$setValidity('nomeexisteValidator', true);

          angular.forEach(scope.nomes, function(item, id) {
            if (item.nome.toLowerCase() === ngModelValue.toLowerCase()) {
              ctrl.$setValidity('nomeexisteValidator', false);
              return;
            }
          });

          // we need to return our ngModelValue, to be displayed to the user(value of the input)
          return ngModelValue;
        }

        ctrl.$parsers.push(customValidator);
      }
    };
});
