angular.module("app").factory("ModelFactory", function($q, $sce, $timeout, $http, config, UsersFactory, $rootScope) {

  //para o LIVRO apenas!
  var _listarTitulosLivro = function() {
    var promessa = $q.defer();
    var lista = [];
    var newObj = {};

    $rootScope.baseRef.child('livros').once('value', function(listData) {
      listData.forEach(function(data) {
        newObj = data.val();

        //a diretiva nome-validator usa uma propriedade "nome"
        //para testar se já existe, então precisamos criar na mão,
        //pois o objeto livro não possui
        newObj.nome = newObj.titulo;

        lista.push(newObj);
      });

      promessa.resolve(lista);
    });

    return promessa.promise;
  };

  var _listarLivrosFull = function() {
    var promessa = $q.defer();
    var ref = $rootScope.baseRef;
    var lista = [];

    ref.child('livros').once('value', function(listData) {
      listData.forEach(function(livroSnap) {
        var livro = _snapshotToObject(livroSnap);
        livro.htmlPopover = $sce.trustAsHtml(
          '<img src="' + livro.capa.downloadUrl + '" style="width: 200px; height: 330px"></img>'
        );

        ref.child('autores').child(livroSnap.val().autor)
          .once('value', function(autorSnap) {
            livro.autor = _snapshotToObject(autorSnap);

            ref.child('categorias').child(livroSnap.val().categoria)
              .once('value', function(categoriasSnap) {
                livro.categoria = _snapshotToObject(categoriasSnap);

                ref.child('idiomas').child(livroSnap.val().idioma)
                  .once('value', function(idiomasSnap) {
                    livro.idioma = _snapshotToObject(idiomasSnap);
                    lista.push(livro);
                  });
              });
          });
        });

        promessa.resolve(lista);
    });

    return promessa.promise;
  };


  var _listar = function(model) {
    var promessa = $q.defer();
    var lista = [];
    var newObj = {};

    $rootScope.baseRef.child(model).once('value', function(listData) {
      listData.forEach(function(data) {
        newObj = data.val();

        newObj.id = data.key;
        lista.push(newObj);
      });

      promessa.resolve(lista);
    })
    .catch(function(err) {
      promessa.reject(err);
    });

    return promessa.promise;
  };

  var _buildModelList = function(list) {
    var lista = [];
    var newObj = {};

    list.forEach(function(data) {
      newObj = data.val();
      newObj.id = data.key;
      lista.push(newObj);
    });

    return angular.copy(lista);
  };

  var _snapshotToObject = function(snapshot) {
    var obj = snapshot.val();
    obj.id = snapshot.key;

    return obj;
  };

  var _getDownloadUrl = function(filename) {
    var promessa = $q.defer();

    var fileRef = firebase.storage().ref('users/' + UsersFactory.getLoggedUserId() + '/' + filename);
    fileRef.getDownloadURL().then(function(url) {
      promessa.resolve(url);
    });

    return promessa.promise;
  };

  var _buscar = function(model, id) {
    var promessa = $q.defer();

    $rootScope.baseRef.child(model).child(id).once('value', function(data) {
      promessa.resolve(data.val());
    });

    return promessa.promise;
  };

  var _salvar = function(model, obj) {
    var promessa = $q.defer();

    var id = obj.id;
    delete obj.id;

    $rootScope.baseRef.child(model).child(id).set(obj).then(function() {
      promessa.resolve(id);
    });

    return promessa.promise;
  };

  var _salvarLivro = function(obj) {
    var promessa = $q.defer();
    var livro = angular.copy(obj);

    var id = obj.id;
    delete obj.id;

    $rootScope.baseRef.child('livros').child(id).set(obj).then(function() {
      promessa.resolve(livro);
    });

    return promessa.promise;
  };

  var _remover = function(model, id) {
    var promessa = $q.defer();
    $rootScope.baseRef.child(model).child(id).remove().then(function() {
      promessa.resolve(id);
    });

    return promessa.promise;
  };

  return {
    listarTitulosLivro: _listarTitulosLivro,
    listar: _listar,
    buscar: _buscar,
    salvar: _salvar,
    salvarLivro: _salvarLivro,
    remover: _remover,
    buildModelList: _buildModelList,
    snapshotToObject: _snapshotToObject,
    getDownloadUrl: _getDownloadUrl,
    listarLivrosFull: _listarLivrosFull
  };
});
