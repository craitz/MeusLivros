angular.module("app").factory("ModalIdiomaFactory", function($uibModal) {
  var modalInstance = {};

  var _open = function(idioma, scope) {
    modalInstance = $uibModal.open({
      templateUrl: 'views/idiomas/modal-idioma.html',
      controller: 'CadastroIdiomasController',
      size: 'sm',
      resolve: {
        novoIdioma: function () {
          return idioma;
        },
        caller: function () {
          return scope;
        }
      }
    });
  };

  var _close = function() {
    modalInstance.close();
  };

  return {
    open: _open,
    close: _close
  };
});
