angular.module('app').factory('UsersFactory', function($q, $rootScope, $interval) {

  var _getLoggedUser = function() {
     return firebase.auth().currentUser;
  };

  var _getLoggedUserName = function() {
    var user = firebase.auth().currentUser;
    if (user) {
      return user.email;
    } else {
      return '';
    }
  };

  var _getLoggedUserId = function() {
    var user = firebase.auth().currentUser;
    if (user) {
      return user.uid;
    } else {
      return '';
    }
  };

  var _login = function(loginData) {
    var promessa = $q.defer();

    firebase.auth().signInWithEmailAndPassword(loginData.user, loginData.password)
    .then(function() {
      promessa.resolve();
    })
    .catch(function(err) {
      promessa.reject(err);
    });

    return promessa.promise;
  };

  var _create = function(loginData) {
    var promessa = $q.defer();

    firebase.auth().createUserWithEmailAndPassword(loginData.user, loginData.password)
    .then(function() {
      promessa.resolve();
    })
    .catch(function(err) {
      promessa.reject(err);
    });

    return promessa.promise;
  };

  var _logout = function() {
    var promessa = $q.defer();

    firebase.auth().signOut()
    .then(function() {
      promessa.resolve();
    })
    .catch(function(err) {
      promessa.reject(err);
    });

    return promessa.promise;
  };

  var _getBaseRef = function() {
    var promessa = $q.defer();

    var waitUserLoad = $interval(function() {
      if ($rootScope.baseRef) {
        promessa.resolve($rootScope.baseRef);
        $interval.cancel(waitUserLoad);
      }
    }, 100);
    return promessa.promise;
  };

  return {
    getLoggedUser: _getLoggedUser,
    getLoggedUserName: _getLoggedUserName,
    getLoggedUserId: _getLoggedUserId,
    login: _login,
    logout: _logout,
    create: _create,
    getBaseRef: _getBaseRef
  };

});
