angular.module("app").factory("ModalAutorFactory", function($uibModal) {
  var modalInstance = {};

  var _open = function(autor, scope) {
    modalInstance = $uibModal.open({
      templateUrl: 'views/autores/modal-autor.html',
      controller: 'CadastroAutoresController',
      size: 'sm',
      resolve: {
        novoAutor: function () {
          return autor;
        },
        caller: function () {
          return scope;
        }
      }
    });
  };

  var _close = function() {
    modalInstance.close();
  };

  return {
    open: _open,
    close: _close
  };
});
