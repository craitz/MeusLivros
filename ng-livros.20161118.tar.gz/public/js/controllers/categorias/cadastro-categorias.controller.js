angular.module('app').controller('CadastroCategoriasController',
function($scope, $rootScope, ModelFactory, ModalCategoriaFactory, novoCategoria, caller) {

  $scope.novoCategoria = novoCategoria;
  $scope.nomes = angular.copy(caller.categorias);
  $scope.title = (novoCategoria === undefined) ? 'Adicionar categoria' : 'Editar categoria';

  $scope.salvarCategoria = function(categoria) {
    //monta o objeto
    var novo = {
      id: (categoria.id === undefined) ? (Date.now() + "") : categoria.id,
      nome: $scope.novoCategoria.nome
    };

    ModelFactory.salvar('categorias', novo).then(function(idNovo) {
      // quando o modal é chamado do cadastro de livros,
      // a combo de autores precisa ser atualizada com o
      // nome do novo autor
      $rootScope.$broadcast('updateCombo', {model: 'categoria', id: idNovo});

      // fecha o modal
      ModalCategoriaFactory.close();
    });
  };

  $scope.fecharModal = function() {
    ModalCategoriaFactory.close();
  };
});
