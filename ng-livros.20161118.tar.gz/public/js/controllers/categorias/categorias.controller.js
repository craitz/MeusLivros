angular.module('app').controller('CategoriasController',
function($scope, $firebaseObject, ModelFactory, ModalCategoriaFactory, UsersFactory) {

  UsersFactory.getBaseRef().then(function(ref) {

    //monitora mudanças no BD
    ref.child('categorias').on('value', function(listData) {
      $scope.$evalAsync(function() {
        $scope.categorias = ModelFactory.buildModelList(listData);
      });
    });

    $scope.ordenarPor = function(campo) {
      $scope.ordenacao = campo;
      $scope.direcao = ($scope.direcao === undefined) ? false : !$scope.direcao;
    };

    $scope.abrirModal = function(categoria) {
      ModalCategoriaFactory.open(angular.copy(categoria), $scope);
    };

    $scope.excluirCategoria = function(categoria) {
      $scope.$evalAsync(
        function() {
          //messagebox de exclusão
          swal(
            {
              title: 'Tem certeza?',
              text: 'Deseja excluir a categoria "' + categoria.nome + '"?',
              showCancelButton: true,
              confirmButtonColor: '#DD6B55',
              confirmButtonText: 'Sim, exclua agora!',
              closeOnConfirm: false
            },
            function(isConfirm) {
              //se confirmou a exclusão
              if (isConfirm) {

                //remove do BD
                ModelFactory.remover('categorias', categoria.id).then(function() {
                  //messagebox confirmando a exclusão
                  swal('Pronto!', 'Categoria "' + categoria.nome + '" excluída com sucesso!', 'success');
                });
              }
            }
          );
        }
      );
    };
  });

});
