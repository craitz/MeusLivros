angular.module('app').controller('DashboardController', function($scope, $sce, $timeout, UsersFactory, ModelFactory) {

  $scope.labelsLine = ["January", "February", "March", "April", "May", "June", "July"];
  $scope.seriesLine = ['Series A', 'Series B'];
  // $scope.colors = ['#97BBCD', '#E59D8C'];
  $scope.colors = ['#949FB1', '#BABDB6'];
  $scope.dataLine = [
    [65, 59, 80, 81, 56, 55, 40],
    [28, 48, 40, 19, 86, 27, 90]
  ];
  $scope.onClick = function (points, evt) {
    console.log(points, evt);
  };
  $scope.datasetOverride = [{ yAxisID: 'y-axis-1' }, { yAxisID: 'y-axis-2' }];
  $scope.optionsLine = {
    scales: {
      yAxes: [
        {
          id: 'y-axis-1',
          type: 'linear',
          display: true,
          position: 'left'
        },
        {
          id: 'y-axis-2',
          type: 'linear',
          display: true,
          position: 'right'
        }
      ]
    }
  };

  $scope.labels = ['2006', '2007', '2008', '2009', '2010', '2011', '2012'];
  $scope.series = ['Series A', 'Series B'];

  $scope.data = [
    [65, 59, 80, 81, 56, 55, 40],
    [28, 48, 40, 19, 86, 27, 90]
  ];

  UsersFactory.getBaseRef().then(function(ref) {

    var autoresDeLivros = [];
    var categoriasDeLivros = [];
    var idiomasDeLivros = [];

    ModelFactory.listarLivrosFull().then(function(lista) {
      $scope.$evalAsync(function() {
        $scope.livros = lista;
      });
    });

    ref.child('autores').once('value', function(listData) {
      $scope.$evalAsync(function() {
        $scope.autores = ModelFactory.buildModelList(listData);
      });
    });

    ref.child('categorias').once('value', function(listData) {
      $scope.$evalAsync(function() {
        $scope.categorias = ModelFactory.buildModelList(listData);
      });
    });

    ref.child('idiomas').once('value', function(listData) {
      $scope.$evalAsync(function() {
        $scope.idiomas = ModelFactory.buildModelList(listData);
      });
    });

  });

});
