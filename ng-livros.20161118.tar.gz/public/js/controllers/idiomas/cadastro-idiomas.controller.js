angular.module('app').controller('CadastroIdiomasController',
function($scope, $rootScope, ModalIdiomaFactory, novoIdioma, caller, ModelFactory) {

  $scope.novoIdioma = novoIdioma;
  $scope.nomes = angular.copy(caller.idiomas);
  $scope.title = (novoIdioma === undefined) ? 'Adicionar idioma' : 'Editar idioma';

  $scope.salvarIdioma = function(idioma) {
    //monta o objeto
    var novo = {
      id: (idioma.id === undefined) ? (Date.now() + "") : idioma.id,
      nome: $scope.novoIdioma.nome
    };

    ModelFactory.salvar('idiomas', novo).then(function(idNovo) {
      // quando o modal é chamado do cadastro de livros,
      // a combo de autores precisa ser atualizada com o
      // nome do novo autor
      $rootScope.$broadcast('updateCombo', {model: 'idioma', id: idNovo});

      // fecha o modal
      ModalIdiomaFactory.close();
    });
  };

  $scope.fecharModal = function() {
    ModalIdiomaFactory.close();
  };
});
